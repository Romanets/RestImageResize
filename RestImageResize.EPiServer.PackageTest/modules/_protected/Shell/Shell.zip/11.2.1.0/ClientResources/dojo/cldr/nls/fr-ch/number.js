//>>built
define("dojo/cldr/nls/fr-ch/number",{"currencyFormat":"¤ #,##0.00;¤-#,##0.00","group":"'","decimal":"."});